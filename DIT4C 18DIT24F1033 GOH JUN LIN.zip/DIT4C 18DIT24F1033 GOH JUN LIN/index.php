<?php
$nama = "GOH JUN LIN";
$nomatrik = "18DIT24F1033";
$kelas = "DIT4C";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profil Saya</title>
</head>
<body>
    <h1>Profil Diri</h1>
    
    <p>Nama: <?= $nama ?></p>
    <p>No. Matrik: <?= $nomatrik ?></p>
    <p>Kelas: <?= $kelas ?></p>

    <img src="profile.jpg" alt="Foto Saya" width="200">
</body>
</html>